import React from "react";

export default function JobCard({ job }) {
  return (
    <article className="bg-white rounded-xl shadow p-4 flex flex-col">
      <header className="flex items-center justify-between mb-3">
        <div>
          <h3 className="font-semibold">{job.title}</h3>
          <div className="text-xs text-gray-500">{job.location} • {job.time}</div>
        </div>
        <div className="text-right">
          <div className="text-sm font-bold">₹{job.price}</div>
          <div className="text-xs text-gray-500">{job.quotes} quotes</div>
        </div>
      </header>

      <p className="text-sm text-gray-700 mb-4">{job.description}</p>

      <div className="mt-auto flex justify-between items-center">
        <div className="text-xs text-gray-500">Posted by {job.poster}</div>
        <div className="flex gap-2">
          <button className="btn border px-3 py-1 rounded">Message</button>
          <button className="btn bg-green-600 text-white px-3 py-1 rounded">Hire</button>
        </div>
      </div>
    </article>
  );
}