import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/" className="font-bold text-xl">HireHand</Link>
          <nav className="space-x-4">
            <Link to="/about" className="text-sm hover:underline">About</Link>
            <a href="#contact" className="text-sm btn bg-blue-600 text-white hover:bg-blue-700">Get Started</a>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
        </Routes>
      </main>

      <footer className="bg-white border-t mt-12">
        <div className="max-w-6xl mx-auto px-6 py-6 text-sm text-gray-600">
          © {new Date().getFullYear()} HireHand — Connect with trusted construction & home professionals.
        </div>
      </footer>
    </div>
  );
}