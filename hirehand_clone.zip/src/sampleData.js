const sampleData = [
  {
    id: 1,
    title: "Bathroom tiling - 6x4 ft",
    description: "Need a skilled tiler to replace broken tiles and re-grout. Supply and labor included.",
    location: "Pune, Maharashtra",
    time: "2 days ago",
    price: "4,200",
    quotes: 3,
    poster: "R. Sharma"
  },
  {
    id: 2,
    title: "Electrical rewiring - 2BHK",
    description: "Partial rewiring and installing new sockets and switches.",
    location: "Mumbai",
    time: "5 days ago",
    price: "12,000",
    quotes: 5,
    poster: "S. Patel"
  },
  {
    id: 3,
    title: "Kitchen sink plumbing",
    description: "Fix leaking under-sink pipe and replace P-trap.",
    location: "Delhi",
    time: "1 day ago",
    price: "800",
    quotes: 2,
    poster: "A. Kumar"
  }
];

export default sampleData;