import React from "react";

export default function About() {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-2xl font-bold mb-2">About HireHand</h2>
      <p className="text-gray-700">We connect homeowners with trusted professionals. Built with modern tooling and a focus on safety, transparency, and fast quotes.</p>
    </div>
  );
}