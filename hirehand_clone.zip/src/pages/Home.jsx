import React, { useState } from "react";
import JobCard from "../ui/JobCard";
import sampleData from "../sampleData";

export default function Home() {
  const [query, setQuery] = useState("");
  const filtered = sampleData.filter((j) =>
    j.title.toLowerCase().includes(query.toLowerCase()) ||
    j.description.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <>
      <section className="grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl font-extrabold mb-4">Hire trusted construction professionals, fast.</h1>
          <p className="mb-6 text-gray-700">Browse rated contractors & handymen, get quotes, and manage jobs — all in one place.</p>

          <div className="flex gap-3">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search trades, e.g. plumber, electrician..."
              className="flex-1 rounded-lg border px-4 py-3"
            />
            <button className="btn bg-blue-600 text-white">Search</button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow p-6">
          <h3 className="font-semibold mb-4">How it works</h3>
          <ol className="list-decimal list-inside text-gray-700 space-y-2">
            <li>Post your job in 60 seconds</li>
            <li>Receive quotes from local experts</li>
            <li>Hire, chat, and pay securely</li>
          </ol>
        </div>
      </section>

      <section className="mt-10">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Open jobs</h2>
          <div className="text-sm text-gray-600">{filtered.length} matching jobs</div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {filtered.map((job) => <JobCard key={job.id} job={job} />)}
        </div>
      </section>
    </>
  );
}